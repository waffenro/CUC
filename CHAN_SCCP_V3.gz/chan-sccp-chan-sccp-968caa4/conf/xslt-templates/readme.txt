language dependent xslt stylesheets for CiscoIpPhone xml messages

Please copy these xslt file to the asterisk DATA_DIR/static-http directory, most likely this will be either:
/usr/share/asterisk/static-http 
or 
/var/lib/asterisk/static-http
